﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace statistics3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] values = textBox1.Text.Split(",");
            double sum = 0;
            foreach(string s in values)
            {
                sum = sum + double.Parse(s);
            }
            double avg = sum / values.Length;
            List<double> squarediffernece = new List<double>();
            foreach(string s in values)
            {
                squarediffernece.Add(Math.Pow(avg - double.Parse(s), 2));
            }
            double variance = squarediffernece.Sum() / values.Length;
            MessageBox.Show("Variance " + variance);
            double std = Math.Sqrt(variance);
            MessageBox.Show("Standard Deviation " + std);
        }
    }
}
